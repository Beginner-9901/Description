rm(list = ls())#清空变量
dir.create("output")
library(GSVA)
library(pheatmap)
library("GSEABase")
library(ggplot2)
library(limma)
library(corrgram)
library(ggthemes)
library(ggpubr)
library(dplyr)

#选择分析版本
#C-GSVA-Function-V1没报告，V2有报告
source("source/GSVA-Function-V2.R")

###功能说明：
#本程序先进行GSVA分析，并绘制分组比较图和热图

###输入参数说明：
#--exp：表达矩阵
#--exp_group：分组文件。样本列名为ID，分组列名为group
#--gmt：gmt文件路径，在source/下可选择
#--con_name/treat_name：对照组/疾病组分组名称
#--con_col/treat_col：对照组/疾病组配色
#--heatmap_up_col/heatmap_down_col：热图上调/下调配色

###input文件夹说明：
#统一替换list.csv：程序需要读取该文件自动进行替换，需要修改第二列，顺序不可以改
#Combined_Datasets_Group.csv：数据集分组，高低风险组也可以
#Combined_Datasets_Matrix_norm.csv：表达矩阵

###gmt文件说明
#gmt最新下载地址：https://www.gsea-msigdb.org/gsea/downloads.jsp

pathway<-GSVA(exp = "input/Combined_Disease_Matrix_norm.csv",exp_group = "input/LASSO_RiskGroup.csv",
              gmt ="source/c2.cp.v2023.2.Hs.symbols.gmt",
              con_name="LowRisk",treat_name="HighRisk",con_col="#D0DAF1",treat_col="#E8A1A1",
              heatmap_up_col="#C8373D",heatmap_down_col="#546497")
rm(list = ls()) 
dir.create("output")
library(org.Hs.eg.db)
library(org.Mm.eg.db)
library(org.Rn.eg.db)
library(clusterProfiler)
library(dplyr)
library(ggplot2)
library("pathview")

source("source/GOKEGG-Function-v2.R")

###功能说明：
#本程序利用输入基因进行GOKEGG注释，并绘制气泡图，柱状图，网络图等

###输入参数说明：
#--gene_input：基因名
#--COLS：柱状图颜色
#--BubblePlot_COLS：气泡图颜色
#--species：人"hsa"，小鼠"mmu"，大鼠"rno"


#过程中请根据output/中的图片结果(.pdf)选择柱状图/气泡图是否翻转xy轴和通路名字换行(可重复调整)
COLS <-c("#FFC640","#9BC7B2","#FFFFB3","#BEBADA")#设定颜色
BubblePlot_COLS<-c("#E64B35","#4DBBD5")
GOKEGG_analysis<-GOKEGG(gene_input="input/degs.csv",COLS=COLS,BubblePlot_COLS=BubblePlot_COLS,species="hsa",width=16,height=8,net_width=8,net_height=6)

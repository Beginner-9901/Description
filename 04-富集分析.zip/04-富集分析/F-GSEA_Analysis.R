rm(list = ls()) 
dir.create("output")
library(limma)
# library(org.Hs.eg.db)
library(clusterProfiler)
library(enrichplot)
library(DOSE)
library(librarian)
library(reshape2)
library(stringr)
library(ggplot2)
library(dplyr)
library(ggthemes)
library(pheatmap)
library(officer)


#选择分析版本
source("source/GSEA-Function-V2.R")

###功能说明
#本程序可进行单独的GSEA，差异分析+GSEA这两种模式的分析
#对于单独的GSEA分析仅绘制山峦图，气泡图，经典图
#对于差异分析+GSEA模式，会绘制火山图，热图，山峦图，气泡图和经典图

###输入参数说明：
#--Difference_analysis：可选FALSE/TURE两种模式，FALSE=仅GSEA分析，TRUE=差异分析+GSEA
#--exp：表达矩阵
#--exp_group：分组信息
#--allFile：第一列为基因名，第二列为logFC的GSEA输入文件，
#如果Difference_analysis=TRUE无需提供，如果Difference_analysis=FALSE必须提供
#--treat_name/con_name：高风险组/低风险组名称，和分组信息中一致
#--treat_col/con_col：高风险组/低风险组分组颜色
#--heatmap_up_col/heatmap_down_col：热图上调/下调颜色
#--gmtFile：source/gmt_dat下面有人或小鼠的基因集，需根据物种进行选择
#--volcano_width/volcano_height：火山图宽高
#--heatmap_width/heatmap_height：热图宽高
#--gseaNb_width/gseaNb_height:GSEA经典图宽高
#--ridgeplot_width/ridgeplot_height：GSEA山峦图宽高
#--dotplot_width/dotplot_height：气泡图宽高

###input文件夹说明：
#统一替换list.csv：程序需要读取该文件自动进行替换，需要修改第二列，顺序不可以改
#GSEA_input.csv：第一列为基因名，第二列为logFC的GSEA输入文件。如果仅GSEA分析，需要提供，否则不需提供。


GSEA<-GSEA_analysis(Difference_analysis=FALSE,exp="input/Disease_Matrix_Counts.csv",
                    exp_group="input/RiskGroup.csv",
                    allFile="input/GSEA_AS_input.csv",
                    gmtFile="source/gmt_dat/c2.all.v2023.2.Hs.symbols.gmt",
                    treat_name="HighRisk",con_name="LowRisk",
                    treat_col="#8ECFC9",con_col="#FFBE7A",
                    volcano_width=8,volcano_height=6,
                    heatmap_width=8,heatmap_height=6,
                    heatmap_up_col="#C8373D",heatmap_down_col="blue",
                    gseaNb_width=5.2,gseaNb_height=5.2,
                    ridgeplot_width=11,ridgeplot_height=5.5,
                    dotplot_width=11,dotplot_height=5.5)

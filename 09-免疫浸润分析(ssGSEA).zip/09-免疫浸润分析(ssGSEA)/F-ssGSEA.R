rm(list = ls())
dir.create("output")
library(GSVA)
library(data.table)
library(dplyr)
library(ComplexHeatmap)
library(ggplot2)
library(corrgram)
library(ggthemes)
library(ggpubr)
library(corrplot)
library(Hmisc)
library("Rmisc")
library("plyr")
source("source/ssGSEA-Function-V2.R")

### 功能说明：
# 本程序先进行高低风险组的差异分析，随后绘制分组比较图，免疫细胞之间相关性热图，基因和免疫细胞的相关性气泡图

### 输入参数说明：
#--exp：表达矩阵
#--exp_group：分组信息。
# treat_name/con_name：高风险组/低风险组名称，和分组信息中一致
# treat_col/con_col：高风险组/低风险组分组颜色
# heatmap_up_col/heatmap_down_col：热图上调/下调颜色

### input文件夹说明：
# 统一替换list.csv：程序需要读取该文件自动进行替换，需要修改第二列，顺序不可以改
# key_genes.csv：关键基因列表
# Combined_Disease_Matrix_norm.csv：表达矩阵
# LASSO_RiskGroup.csv：数据集分组


immu <- ssGSEA(exp = "input/Combined_Datasets_Matrix.csv",
               exp_group = "input/Combined_Datasets_Group.csv",
               key_genes = "input/key_genes.csv",con_name = "Control",
               treat_name = "DKD", treat_col = "#C99E8C", con_col = "#465E65",
               heatmap_up_col = "#CD534C", heatmap_down_col = "#7AA6DC")
